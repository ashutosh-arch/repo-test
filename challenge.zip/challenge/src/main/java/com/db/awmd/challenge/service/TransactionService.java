package com.db.awmd.challenge.service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.exception.InsufficientFundsException;
import com.db.awmd.challenge.repository.AccountsRepository;

import lombok.Getter;

@Service
public class TransactionService {

	@Getter
	private final AccountsRepository accountsRepository;

	@Autowired
	public TransactionService(AccountsRepository accountsRepository) {
		this.accountsRepository = accountsRepository;
	}

	public void transferFunds(final Account accountFrom, final Account accountTo, final BigDecimal amount)
			throws InsufficientFundsException {
		this.accountsRepository.transferFunds(accountFrom, accountTo, amount);
	}

}
