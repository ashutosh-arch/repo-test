package com.db.awmd.challenge.web;

import java.math.BigDecimal;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.domain.Transaction;
import com.db.awmd.challenge.exception.InsufficientFundsException;
import com.db.awmd.challenge.service.AccountsService;
import com.db.awmd.challenge.service.NotificationService;
import com.db.awmd.challenge.service.TransactionService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v1/transaction")
@Slf4j
public class TransactionController {

	private final TransactionService transactionService;

	private final NotificationService notificationService;

	private final AccountsService accountsService;

	@Autowired
	public TransactionController(TransactionService transactionService, NotificationService notificationService,
			AccountsService accountsService) {
		this.transactionService = transactionService;
		this.notificationService = notificationService;
		this.accountsService = accountsService;
	}

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> transferFunds(@RequestBody @Valid Transaction transaction) {

		Account accountFrom = accountsService.getAccount(transaction.getAccoutFromId());
		Account accountTo = accountsService.getAccount(transaction.getAccountToId());
		BigDecimal amount = transaction.getAmount();

		log.info("initiating funds transfer from account {} to account {}", accountFrom, accountTo);

		try {
			this.transactionService.transferFunds(accountFrom, accountTo, amount);
		} catch (InsufficientFundsException ex) {
			return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
		}
		notifyAccounts(accountFrom, accountTo, amount);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	private void notifyAccounts(Account accountFrom, Account accountTo, BigDecimal amount) {
		notificationService.notifyAboutTransfer(accountFrom,
				"amount :" + amount + " has been debited and account :" + accountTo.getAccountId() + " has been credited");
		notificationService.notifyAboutTransfer(accountTo,
				"amount :" + amount + " has been credited from account :" + accountFrom.getAccountId());
	}
}
