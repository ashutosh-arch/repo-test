package com.db.awmd.challenge;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.service.AccountsService;
import com.db.awmd.challenge.service.NotificationService;

@RunWith(SpringRunner.class)
@SpringBootTest
@WebAppConfiguration
public class TransactionControllerTest {

	private MockMvc mockMvc;

	@Autowired
	private AccountsService accountsService;

	@Mock
	private NotificationService notificationService;

	@Autowired
	private WebApplicationContext webApplicationContext;

	List<Account> accounts;

	@Before
	public void prepareMockMvc() {
		this.mockMvc = webAppContextSetup(this.webApplicationContext).build();

		// Reset the existing accounts before each test.
		accountsService.getAccountsRepository().clearAccounts();
	}

	@Test
	public final void testTransferFunds() throws Exception {

		accounts = createTestAccounts();

		this.mockMvc
				.perform(post("/v1/transaction").contentType(MediaType.APPLICATION_JSON)
						.content("{\"accoutFromId\":\"Id-123\",\"accountToId\":\"Id-124\",\"amount\":200}"))
				.andExpect(status().isOk());

		assertThat(accounts.get(0).getBalance()).isEqualByComparingTo("800");
		assertThat(accounts.get(1).getBalance()).isEqualByComparingTo("700");

	}

	@Test
	public final void testNegativeTransferFunds() throws Exception {

		accounts = createTestAccounts();

		this.mockMvc
				.perform(post("/v1/transaction").contentType(MediaType.APPLICATION_JSON)
						.content("{\"accoutFromId\":\"Id-123\",\"accountToId\":\"Id-124\",\"amount\":-200}"))
				.andExpect(status().isBadRequest());

	}

	private List<Account> createTestAccounts() {
		List<Account> accounts = new ArrayList<Account>();
		Account accountFrom = new Account("Id-123", new BigDecimal(1000));
		Account accountTo = new Account("Id-124", new BigDecimal(500));

		accountsService.createAccount(accountFrom);
		accountsService.createAccount(accountTo);
		accounts.add(accountFrom);
		accounts.add(accountTo);
		return accounts;
	}

}
