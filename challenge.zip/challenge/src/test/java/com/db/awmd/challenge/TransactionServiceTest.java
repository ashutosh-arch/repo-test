package com.db.awmd.challenge;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.repository.AccountsRepository;
import com.db.awmd.challenge.service.AccountsService;
import com.db.awmd.challenge.service.TransactionService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TransactionServiceTest {

	@Autowired
	private TransactionService transactionService;

	private AccountsRepository accountRepository;

	@Test
	public void transferFunds() {

		accountRepository = this.transactionService.getAccountsRepository();

		String accountFromId = "Id1-" + System.currentTimeMillis();
		String accountToId = "Id2-" + System.currentTimeMillis();
		BigDecimal amount = new BigDecimal(2000);
		BigDecimal initialBalance = new BigDecimal(5000);

		Account accountFrom = new Account(accountFromId);
		Account accountTo = new Account(accountToId);
		accountFrom.setBalance(initialBalance);

		accountRepository.createAccount(accountFrom);
		accountRepository.createAccount(accountTo);

		transactionService.transferFunds(accountFrom, accountTo, amount);

		assertEquals(initialBalance.subtract(amount), accountFrom.getBalance());
		assertEquals(amount, accountTo.getBalance());
	}

}
